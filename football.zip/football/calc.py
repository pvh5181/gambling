import os
import sys
from bs4 import BeautifulSoup


# csv files each game 


# adjust for garbage time points -> team score in garbage time 
#strength of team vs strength of other team, which parts are strong -> run, defense, pass
# spread, over, under, ml, exact score  

"""
import requests
import html
from bs4 import BeautifulSoup
uri = "https://www.pro-football-reference.com/years/" + year + "/week_" + week + ".htm"
r = requests.get(uri)
text = (html.unescape(r.text))
soup = BeautifulSoup(text)
for i in soup.find_all("td", {"class": "right gamelink"}):
    print(i.text)
"""

import requests
import html
from bs4 import BeautifulSoup

path = r"/Users/p/desktop/football/"
pathlst = os.listdir(path)
weeklst = []

team1 = ""
team2 = ""
expected_points = ""
teamstats = ""
scoring = ""
lst = []
lst2 = []
lst3 = []
lst4 = []

lst5 = []
count = 0
tot = 0
print(pathlst)

for i in pathlst:
    if ((i!=".DS_Store") and (i!="scrape.py") and (i!="calc.py")):
        weeklst = os.listdir(i)
        for j in weeklst:
            if i:
                if j!=".DS_Store":
                    path = i+"/"+j
                    gamelst = os.listdir(path)
                    for k in gamelst:
                        if k!= ".DS_Store":
                            with open(path + "/" + k) as fd:
                                s = fd.read()
                            lines = s.split("\n")
                            for l in lines[0].split(","):
                                if l.find("-") != -1:
                                    tmp = l.split(" ")
                                    spread = tmp[len(tmp)-1]
                                    team = tmp[len(tmp)-2]
                                    
                            for l in lines[1:]:
                                m = (l.split(","))
                                if m[0] == team and float(m[1]) == -1*float(spread):
                                    count+=1
                            tot+=1
print(count, tot)
                        
                            
