import os
import sys
from bs4 import BeautifulSoup


# csv files each game 


# adjust for garbage time points -> team score in garbage time 
#strength of team vs strength of other team, which parts are strong -> run, defense, pass
# spread, over, under, ml, exact score  

"""
import requests
import html
from bs4 import BeautifulSoup
uri = "https://www.pro-football-reference.com/years/" + year + "/week_" + week + ".htm"
r = requests.get(uri)
text = (html.unescape(r.text))
soup = BeautifulSoup(text)
for i in soup.find_all("td", {"class": "right gamelink"}):
    print(i.text)
"""

import requests
import html
from bs4 import BeautifulSoup

path = r"/Users/p/desktop/football/"
pathlst = os.listdir(path)
weeklst = []

team1 = ""
team2 = ""
expected_points = ""
teamstats = ""
scoring = ""
lst = []
lst2 = []
lst3 = []
lst4 = []

lst5 = []
"""
for i in pathlst:
	if ((i!=".DS_Store") and (i!="scrape.py")):
		weeklst = os.listdir(i)
		print(weeklst)
		for j in weeklst:
			print(i)
			
			if i:
				temp = str(path) + str(i) +r"/"+ str(j)
				if j!=".DS_Store":
					files = os.listdir(temp)
					for k in files:
						if (k!=".DS_Store"):
							if ((temp+r"/"+k).find("html"))!=-1:
								with open((temp+r"/"+k), 'r') as fd:
									name = k.split("-")[0]
									soup = BeautifulSoup(fd.read())
                                    
									#print(soup.find("div", {"id": "div_team_stats"}))
									#print(soup.find("table", {"id": "expected_points"}))
                                    
									#for tr in (soup.find_all("table", {"id": "team_stats"})):
									#	q = 0
									#	for m in (tr.find_all('td')):
									#		if ((q%2) ==0):
									#			lst3.append(m.string)
									#		else:
									#			lst4.append(m.string)
									#		q+=1
									#for tr in (soup.find_all("table", {"id": "game_info"})):
									#	for m in (tr.find_all('td')):
									#		lst5.append(m.string)
									#		#print(i.string)
									#		#pass
                        
                                    
									for tr in (soup.find_all("table", {"id": "expected_points"})):
										for m in (tr.find_all('td')):
											if len(lst)<15:
												lst.append(m.string)
											else:
												lst2.append(m.string)
											
										print("--")	
										
									print(lst)
									print(lst2)
	
									s = ""
									for m in lst:
										s+= m + ","
									s+="\n"
									for m in lst2:
										s+= m + ","
									s+="\n"
									for m in lst3:
										s+= m + ","
									s+="\n"
									for m in lst4:
										s+= m + ","
									s+="\n"
									print(lst5)
									for m in lst5:
										s+= str(m) + ","
									s+="\n"
									with open(temp+r"/"+name+".csv", 'w') as fd2:
										fd2.write(s)	
									lst = []
									lst2 = []
									lst3 = []
									lst4 = []
									lst5 = []
									#print(soup.find("tr", {"data-row": "0"}))

"""
for i in pathlst:
    if ((i!=".DS_Store") and (i!="scrape.py")):
        weeklst = os.listdir(i)
        for j in weeklst:
            if i:
                if j!=".DS_Store":
                    uri = "https://www.pro-football-reference.com/years/" + i + "/week_" + j.split("week")[1] + ".htm"
                    r = requests.get(uri)
                    text = (html.unescape(r.text))
                    soup = BeautifulSoup(text)
                    

                    for k in soup.find_all("td", {"class": "right gamelink"}):
                        for a in k.find_all('a', href=True):
                            url = "https://www.pro-football-reference.com" + (a['href'])
                            
                            r1 = requests.get(url)
                            text2 =(html.unescape(r1.text))
                            soup2 = BeautifulSoup(text2)
                            
                            s = ""
                            
                            for o in soup2.find_all('div', {"class": "content_grid"}):
                                for tr in (o.find_all('div', {"id": "all_game_info"})):
                                
                                    linesoup = BeautifulSoup(str(tr).split("<!--")[1])
                                    for td in (linesoup.find_all("td", {"class": "center"})):
                                        s+= (td.text) + ","
                            s+="\n"
                            
                            

                                
                            
                            
                            
                            temp_ = (soup2.find_all('div', {"id": "all_expected_points"}))
                            newsoup = BeautifulSoup(  str(temp_).split("</thead>")[1])
                            
                            
                            name = ""
                            for tr in newsoup.find_all("tr"):
                                s += (tr.find_all("th", {"scope": "row"})[0].text) + ","
                                name += (tr.find_all("th", {"scope": "row"})[0].text) + "@"
                                for td in (tr.find_all("td")):
                                    s += (td.text) + ","
                                s += "\n"
                                
                            csv = (path + i + "/" + j + "/" + name[:len(name)-1] + ".csv")
                            
                            
                            print(csv)
                            with open(csv, 'w') as fd2:
                                fd2.write(s)
                            
                            
                            
                                #    print(_j.find_all("table", {"id": "expected_points"}))
                            #print(temp.find_all('table', {"id": "expected_points"}))
                            #print(soup2.find_all("div", {"class":"table_container"}, {"id": "expected_points"}))
                            #for td in (soup2.find_all("table", {"class":"sortable stats_table now_sortable"}, {"id": "expected_points"})):
                            #   for tr in td.find_all("td"):
                            #      print(tr.text)
                            #for tr in (soup.find_all("table", {"id": "expected_points"})):
                                #print(tr.text)
                                #for l in (tr.find_all("td")):
                                #    print(l.text)
                            #tr_elements = soup2.find_all('table', {'id': 'expected_points'})
                            # for l in (tr_elements):
                            #     print(l)
                            #print(soup2)
                            
                            """
                            lst = []
                            lst2 = []
                            for tr in (soup.find_all("table", {"id": "expected_points"})):
                                print(tr)
                                for m in (tr.find_all('td')):
                                    if len(lst)<15:
                                        lst.append(m.string)
                                    else:
                                        lst2.append(m.string)
                            print(lst)
                            print(lst2)
                            print("--")
                            """
                    """
                    for k in files:
                        if (k!=".DS_Store"):
                            if ((temp+r"/"+k).find("html"))!=-1:
                                with open((temp+r"/"+k), 'r') as fd:
                                    name = k.split("-")[0]
                                    soup = BeautifulSoup(fd.read())
                                    
                                    #print(soup.find("div", {"id": "div_team_stats"}))
                                    #print(soup.find("table", {"id": "expected_points"}))
                                    
                                    #for tr in (soup.find_all("table", {"id": "team_stats"})):
                                    #    q = 0
                                    #    for m in (tr.find_all('td')):
                                    #        if ((q%2) ==0):
                                    #            lst3.append(m.string)
                                    #        else:
                                    #            lst4.append(m.string)
                                    #        q+=1
                                    #for tr in (soup.find_all("table", {"id": "game_info"})):
                                    #    for m in (tr.find_all('td')):
                                    #        lst5.append(m.string)
                                    #        #print(i.string)
                                    #        #pass
                        
                                    
                                    for tr in (soup.find_all("table", {"id": "expected_points"})):
                                        for m in (tr.find_all('td')):
                                            if len(lst)<15:
                                                lst.append(m.string)
                                            else:
                                                lst2.append(m.string)
                                            
                                        print("--")
                                        
                                    print(lst)
                                    print(lst2)
    
                                    s = ""
                                    for m in lst:
                                        s+= m + ","
                                    s+="\n"
                                    for m in lst2:
                                        s+= m + ","
                                    s+="\n"
                                    for m in lst3:
                                        s+= m + ","
                                    s+="\n"
                                    for m in lst4:
                                        s+= m + ","
                                    s+="\n"
                                    print(lst5)
                                    for m in lst5:
                                        s+= str(m) + ","
                                    s+="\n"
                                    with open(temp+r"/"+name+".csv", 'w') as fd2:
                                        fd2.write(s)
                                    lst = []
                                    lst2 = []
                                    lst3 = []
                                    lst4 = []
                                    lst5 = []
                                    #print(soup.find("tr", {"data-row": "0"}))
                    """
"""
csv = ("/Users/p/desktop/football" + "asdjalskj" + ".csv")
s = ""
for i in pathlst:
    if ((i!=".DS_Store") and (i!="scrape.py")):
        weeklst = os.listdir(i)
        for j in weeklst:
            if i:
                if j!=".DS_Store":
                    uri = "https://www.pro-football-reference.com/years/" + i + "/week_" + j.split("week")[1] + ".htm"
                    r = requests.get(uri)
                    text = (html.unescape(r.text))
                    soup = BeautifulSoup(text)
                    for k in soup.find_all("td", {"class": "right gamelink"}):
                        for a in k.find_all('a', href=True):
                            url = "https://www.pro-football-reference.com" + (a['href'])
                            
                            r1 = requests.get(url)
                            text2 =(html.unescape(r1.text))
                            soup2 = BeautifulSoup(text2)
                            temp_ = (soup2.find_all('div', {"id": "all_game_info"}))
                            #print(soup2)
                            #print(str(temp_).split("Vegas")[1])
                            #print(i, j)
                            s += i + j + "\n" + str(temp_).split("Vegas")[1] + "\n\n-----------"
with open(csv, 'w') as fd2:
    fd2.write(s)
"""
